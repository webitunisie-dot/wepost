<?php

/**
 * Togo functions and definitions
 *
 * @package togo
 */

require_once get_template_directory() . '/inc/init.php';
