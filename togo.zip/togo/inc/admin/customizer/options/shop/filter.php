<?php
// Single Product
Togo_Kirki::add_section('product_filter', array(
    'title'    => esc_html__('Product Filter', 'togo'),
    'panel'    => $panel,
    'priority' => $priority++,
));
