<?php

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('Togo_Ajax_Include')) {

	/**
	 *  Class Togo_Ajax
	 */
	class Togo_Ajax_Include
	{

		/**
		 * The constructor.
		 */
		public function __construct() {}
	}

	new Togo_Ajax_Include();
}
