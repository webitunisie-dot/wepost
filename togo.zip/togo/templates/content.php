<?php
do_action('togo_open_post_loop_content');
do_action('togo_close_post_loop_content');
