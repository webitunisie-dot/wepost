<div class="post-title">
    <h1 class="entry-title heading-font"><?php the_title(); ?></h1>
</div>