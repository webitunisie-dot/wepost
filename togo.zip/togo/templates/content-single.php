<?php

/**
 * The template for displaying all single posts.
 *
 * @link    https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 */

do_action('togo_open_post_content');
the_content();
do_action('togo_close_post_content');
